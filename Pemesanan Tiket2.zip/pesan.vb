﻿Public Class pesan
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub pesan_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class