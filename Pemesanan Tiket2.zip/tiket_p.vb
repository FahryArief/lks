﻿Public Class tiket_p
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        pesan.Show()
    End Sub
End Class